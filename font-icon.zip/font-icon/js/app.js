$(function() {
	var $body = $('body');
	smoothScroll.init();
});